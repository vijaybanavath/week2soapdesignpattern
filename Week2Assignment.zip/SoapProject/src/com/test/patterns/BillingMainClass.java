package com.test.patterns;

import com.test.patterns.factory.SoapType;
import com.test.patterns.factory.SoapTypeFactory;
import com.test.patterns.singleton.UnitsTracker;

public class BillingMainClass {

	public static void main(String[] args) {
		int noOfUnits = 10;
		
		UnitsTracker unitsTrackerObj = UnitsTracker.getInstance();
		
		
		SoapType bathSoap = SoapTypeFactory.getSoap("Bath");
		double bathSoapprice = bathSoap.calculatePrice(noOfUnits);
		System.out.println("Price of Bath Soap = " + bathSoapprice);
		System.out.println("No Of Unit Sold = " + unitsTrackerObj.totalUnitsSold());
		
		
		SoapType washingSoap = SoapTypeFactory.getSoap("Washing");
		double washingSoapPrice = washingSoap.calculatePrice(noOfUnits);
		System.out.println("Price of Washing Soap = " + washingSoapPrice);
		System.out.println("No Of Unit Sold = " + unitsTrackerObj.totalUnitsSold());
		

	}

}
