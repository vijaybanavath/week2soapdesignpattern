package com.test.patterns.factory;

public class WashingSoap extends SoapType {

	@Override
	public double getPrice() {
		return (double) 15;
	}

}
