package com.test.patterns.factory;

public class SoapTypeFactory {
	
	public static SoapType getSoap(String soapName) {
		if("Washing".equals(soapName)) {
			return new WashingSoap();
		}
		if("Bath".equals(soapName)) {
			return new BathSoap();
		}
		return null;
	}

}
