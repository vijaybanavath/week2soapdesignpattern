package com.test.patterns.factory;

import com.test.patterns.singleton.UnitsTracker;

public abstract class SoapType {
	
	
	public double calculatePrice(int units) {
		UnitsTracker.getInstance().addUnitSold(units);
		return units*getPrice();
	}
	
	public abstract double getPrice();
}
