package com.test.patterns.factory;

public class BathSoap extends SoapType {

	@Override
	public double getPrice() {
		return (double) 25;
	}

}
